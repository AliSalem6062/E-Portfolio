
import unittest
from pathlib import Path
from aroas.crawler import crawl_local_html
from aroas.processor import build_tfidf, vector_query, cosine_rank

BASE = Path(__file__).resolve().parents[1]

class TestProcessor(unittest.TestCase):
    def setUp(self):
        self.docs = crawl_local_html(BASE / "sample_data")
        self.idf, self.dv = build_tfidf(self.docs)

    def test_tokenisation_and_idf(self):
        # idf must exist for common term 'ranking'
        qw = vector_query("ranking", self.idf)
        self.assertTrue("ranking" in qw or "ranking" in self.idf)

    def test_deterministic_ranking(self):
        q = "open access ranking"
        r1 = cosine_rank(vector_query(q, self.idf), self.dv)
        r2 = cosine_rank(vector_query(q, self.idf), self.dv)
        self.assertEqual(r1, r2)

if __name__ == "__main__":
    unittest.main()
