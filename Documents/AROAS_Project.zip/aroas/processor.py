
import math
import re
from collections import Counter, defaultdict
from typing import List, Dict, Tuple

TOKEN_RE = re.compile(r"[a-z0-9]+" )

def tokenize(text: str):
    return TOKEN_RE.findall(text.lower())

def build_tfidf(docs: List[Dict[str,str]]) -> Tuple[Dict[str,float], List[Dict]]:
    """
    Returns (idf, doc_vectors)
    doc_vectors[i] -> {"id": ..., "norm": float, "weights": {term: tfidf}}
    """
    # 1) Document term frequencies over title+abstract
    d_tfs = []
    df = Counter()
    for d in docs:
        text = (d.get("title","") + " " + d.get("abstract","")).strip()
        toks = tokenize(text)
        tf = Counter(toks)
        d_tfs.append(tf)
        for term in tf:
            df[term] += 1
    N = len(docs)
    # 2) IDF (log base e): 1 + log(N / (1+df))
    idf = {t: 1.0 + math.log(N / (1.0 + c)) for t, c in df.items()}
    # 3) Build weighted vectors
    doc_vectors = []
    for d, tf in zip(docs, d_tfs):
        weights = {}
        for t, f in tf.items():
            weights[t] = (f * idf.get(t, 0.0))
        norm = math.sqrt(sum(w*w for w in weights.values())) or 1.0
        doc_vectors.append({"id": d["id"], "weights": weights, "norm": norm})
    return idf, doc_vectors

def vector_query(query: str, idf: Dict[str,float]) -> Dict[str,float]:
    qtf = Counter(tokenize(query))
    qweights = {t: (f * idf.get(t, 0.0)) for t, f in qtf.items()}
    qnorm = math.sqrt(sum(w*w for w in qweights.values())) or 1.0
    # normalise inline for cosine
    for t in list(qweights.keys()):
        qweights[t] /= qnorm
    return qweights

def cosine_rank(qw: Dict[str,float], doc_vectors: List[Dict]) -> List[Tuple[str,float]]:
    scores = []
    for dv in doc_vectors:
        num = 0.0
        for t, qw_t in qw.items():
            dw = dv["weights"].get(t, 0.0)
            if dw:
                num += (qw_t * (dw / dv["norm"]))
        scores.append((dv["id"], num))
    # stable sort by score desc then id asc
    scores.sort(key=lambda x: (-x[1], x[0]))
    return scores

def top_terms_per_doc(idf: Dict[str,float], doc_vectors: List[Dict], k: int = 5):
    out = []
    for dv in doc_vectors:
        top = sorted(dv["weights"].items(), key=lambda kv: -kv[1])[:k]
        out.append((dv["id"], top))
    return out
