
import re
from pathlib import Path
from typing import List, Dict

META_RE = re.compile(r'<meta\s+name=["\'](citation_title|citation_author|citation_abstract)["\']\s+content=["\'](.*?)["\']\s*/?>', re.I)
P_RE = re.compile(r'<p[^>]*>(.*?)</p>', re.I | re.S)

def parse_html(html: str) -> Dict[str, str]:
    meta = {m.group(1).lower(): m.group(2).strip() for m in META_RE.finditer(html)}
    if "citation_abstract" not in meta:
        # fallback to first paragraph
        m = P_RE.search(html)
        if m:
            # strip tags crudely
            para = re.sub(r'<[^>]+>', ' ', m.group(1))
            meta["citation_abstract"] = " ".join(para.split())
        else:
            meta["citation_abstract"] = ""
    return {
        "title": meta.get("citation_title", ""),
        "authors": meta.get("citation_author", ""),
        "abstract": meta.get("citation_abstract", ""),
    }

def crawl_local_html(folder: Path) -> List[Dict[str, str]]:
    docs = []
    for p in sorted(folder.glob("*.html")):
        html = p.read_text(encoding="utf-8", errors="ignore")
        meta = parse_html(html)
        meta["id"] = p.stem
        meta["source_path"] = str(p)
        docs.append(meta)
    return docs
