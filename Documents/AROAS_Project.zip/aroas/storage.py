
import csv
from pathlib import Path
from typing import Dict, List, Tuple

def write_ranked(results: List[Tuple[str,float]], outpath: Path):
    outpath.parent.mkdir(parents=True, exist_ok=True)
    with outpath.open("w", newline="", encoding="utf-8") as f:
        w = csv.writer(f)
        w.writerow(["doc_id","score"])
        for doc_id, score in results:
            w.writerow([doc_id, f"{score:.6f}"])

def write_tfidf_snapshot(idf: Dict[str,float], top_terms: List[Tuple[str,List[Tuple[str,float]]]], outpath: Path):
    outpath.parent.mkdir(parents=True, exist_ok=True)
    with outpath.open("w", newline="", encoding="utf-8") as f:
        w = csv.writer(f)
        w.writerow(["doc_id","term","weight","idf(term)"])
        idf_default = 0.0
        for doc_id, pairs in top_terms:
            for term, weight in pairs:
                w.writerow([doc_id, term, f"{weight:.6f}", f"{idf.get(term, idf_default):.6f}"])
