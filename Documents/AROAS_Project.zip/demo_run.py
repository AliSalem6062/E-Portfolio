
import sys, datetime
from pathlib import Path
from aroas.crawler import crawl_local_html
from aroas.processor import build_tfidf, vector_query, cosine_rank, top_terms_per_doc
from aroas.storage import write_ranked, write_tfidf_snapshot

BASE = Path(__file__).resolve().parent
SAMPLE = BASE / "sample_data"
OUT = BASE / "outputs"

def main():
    query = " ".join(sys.argv[1:]).strip() or "open access discovery ranking scholarly graphs"
    docs = crawl_local_html(SAMPLE)
    idf, dv = build_tfidf(docs)
    qw = vector_query(query, idf)
    ranked = cosine_rank(qw, dv)
    write_ranked(ranked, OUT / "ranked_results.csv")
    write_tfidf_snapshot(idf, top_terms_per_doc(idf, dv, k=7), OUT / "tfidf_weights.csv")
    # log
    log = OUT / "run_log.txt"
    log.write_text(f"[{datetime.datetime.utcnow().isoformat()}Z] Query: {query}\nDocs: {len(docs)}\nTop: {ranked[:3]}\n", encoding="utf-8")
    print("OK")
    print(f"Query: {query}")
    print("Top results:", ranked[:3])
    print(f"Wrote: {OUT/'ranked_results.csv'}")
    print(f"Wrote: {OUT/'tfidf_weights.csv'}")
    print(f"Log: {log}")

if __name__ == "__main__":
    main()
