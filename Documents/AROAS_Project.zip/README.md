# AROAS – Minimal Demo (Deterministic, Offline)

This is a compact, self-contained demo for the **Academic Research Online Agent System (AROAS)**.  
It demonstrates the core pipeline *without internet access* using three sample HTML files that include scholarly meta tags.

## What it does

- **Crawler**: Reads local HTML files in `sample_data/`, extracts minimal metadata:
  - `citation_title`
  - `citation_author`
  - `citation_abstract` (falls back to first paragraph if absent)
- **Processor**: Tokenises (lowercase, alphanumerics), computes **TF–IDF** from scratch, and ranks documents for a given query over title+abstract.
- **Storage**: Writes ranked results and TF–IDF details to CSV in `outputs/`.
- **Determinism**: No randomness in ranking; repeated runs yield identical results.

## Quick start

```bash
python demo_run.py "graph neural networks for scholarly ranking"
```

This will produce:

- `outputs/ranked_results.csv` – ranked docs with scores
- `outputs/tfidf_weights.csv` – per-term IDF and top weighted terms by doc
- `outputs/run_log.txt` – simple run log

If you run with no arguments, a default query is used:

```bash
python demo_run.py
```

## Tests

Run unit tests:

```bash
python -m unittest -v
```

## Notes

- Parquet is mentioned in the report; for simplicity and portability here we write **CSV** only. Switching to Parquet would require a library such as `pyarrow` and is left as a small extension.
- The crawler is intentionally simple and offline to keep marking reproducible. You can add real spiders later (e.g., Scrapy) while preserving the same `Processor` interface.
- **Ethics & robots**: When you extend this demo to live crawling, implement robots.txt observance and rate limiting as described in the report.

## File structure

```
project/
  README.md
  demo_run.py
  aroas/
    __init__.py
    crawler.py
    processor.py
    storage.py
  sample_data/
    doc1.html
    doc2.html
    doc3.html
  outputs/        # generated at runtime
  tests/
    test_processor.py
```

